## <b> Pre-test</b>
#### Please attempt the following questions

<br>
Q 1. The purpose of using fine aggregate in concrete is to <br>
a. Fill voids<br>
b. Workability agent <br>
<b>c. Both A and B</b><br>
d. Provide strength<br><br>

Q 2. Which of the following will float in water? The density of water is 1g/ml <br>
<b>a. Object 1: m = 5g and v = 2ml</b><br>
b. Object 2: m = 3g and v = 4ml<br>
c. Object 3: m = 3g and v = 1ml<br>
d. Object 4: m = 4g and v = 3ml<br>

Q 3. Presence of large number of deleterious materials on aggregate results in high Specific Gravity value.  <br>
a. True<br>
<b>b. False</b><br>

Q 4. The Specific Gravity of cement is greater than 3.19, it indicates that <br>
a. It has more moisture content<br>
b. The cement is not minced finely as per the industry standard<br>
c. Both A and B<br>
<b>d. None of these</b><br>

Q 5. According to the IS Code, Zone IV aggregate is finer than Zone I aggregate. <br>
a. No<br>
<b>b. Yes</b>
