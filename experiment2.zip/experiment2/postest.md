## Post test
<br>
Q 1. Specific Gravity is important in <br>
a. Mix design<br>
b. Deleterious material identification<br>
c. Material property change<br>
<b>d. All the above</b><br><br>

Q 2. Stock cements are avoided in concreting especially because of  <br>
<b>a. Moisture activity</b><br>
b. Chemical activity<br>
c. Thermal activity<br>
d. None of the above<br>

Q 3. The major factor which affect the Specific Gravity is <br>
a. Pores<br>
b. Moisture contents<br>
<b>c. Both A and B</b><br>
d. None of these<br>

Q 4. According to standard the Specific Gravity of coarse aggregate should be in between <br>
a. 27-29<br>
<b>b. 25-28</b><br>
c. 315-319<br>
d. 26-285 <br>

Q 5. Why is kerosene used to determine the Specific Gravity of cement?  <br>
a. Its Specific Gravity is higher than cement<br>
<b>b. It does not react with cement as water does</b><br>
c. Its Specific Gravity is lower than cement<br>
d. None of these<br>
