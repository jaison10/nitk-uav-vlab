1. IS 4031 (Part II) - 1988, Methods of Physical Tests for Hydraulic Cement.<br>

2. IS : 2386 (Part III)-1963: Methods of Test for Aggregates for Concrete,1963.<br>

3. IS 383-1970: Specification for Coarse and Fine Aggregates From Natural Sources for Concrete, Second Revision,1970.<br>

4. B. C. Punmia, Ashok Kumar Jain, Soil Mechanics and Foundations, Laxmi Publications,2005.<br>

5. M.S. Shetty, Concrete Technology, S. Chand Publications, 2009.<br>

6. M.L. Gambhir, Concrete Technology, Tata McGraw-Hill Education, 2004.<br>

7. Miller, R. W., Flow Measurement Engineering Handbook, Second Edition, McGraw-Hill, 1989.
