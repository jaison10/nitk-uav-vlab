## Determination of Motor Thrust     
